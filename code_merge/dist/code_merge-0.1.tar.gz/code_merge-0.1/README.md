## Tool Collection Project - Code Merging Tool

### Code Merging Tool
Input a file path to merge code files in the project folder, supporting both CLI with arguments and GUI execution.